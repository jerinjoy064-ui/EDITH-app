# EDITH - Android app (Stage 1)

Upload (Termux):
    pkg install git
    cd EDITH
    git init && git branch -M main
    git add . && git commit -m "EDITH stage 1"
    git remote add origin https://github.com/joyjerin894-cloud/AndroidForge.git
    git push -u origin main      # use a GitHub personal access token as password

Build: GitHub > Actions > "Build EDITH" > latest run > Artifacts > EDITH-apks.
Release signing: add secrets KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD.
Publish release: git tag v1.0.0 && git push origin v1.0.0
