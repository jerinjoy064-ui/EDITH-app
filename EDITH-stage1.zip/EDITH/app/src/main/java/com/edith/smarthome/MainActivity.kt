package com.edith.smarthome

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.edith.smarthome.ui.dashboard.DashboardScreen
import com.edith.smarthome.ui.theme.EdithTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EdithTheme {
                DashboardScreen()
            }
        }
    }
}
