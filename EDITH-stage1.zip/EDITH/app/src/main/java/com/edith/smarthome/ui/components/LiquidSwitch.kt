package com.edith.smarthome.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.edith.smarthome.ui.theme.Cyan
import com.edith.smarthome.ui.theme.Violet
import kotlin.math.roundToInt

@Composable
fun LiquidSwitch(
    checked: Boolean,
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val progress by animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
        label = "liquid"
    )
    val density = LocalDensity.current
    val travel = with(density) { 24.dp.toPx() }
    val pad = with(density) { 3.dp.toPx() }
    val p = progress.coerceIn(0f, 1f)
    val trackColor = lerp(Color.White.copy(alpha = 0.14f), Cyan.copy(alpha = 0.85f), p)

    Box(
        modifier = modifier
            .alpha(if (enabled) 1f else 0.4f)
            .size(width = 58.dp, height = 34.dp)
            .clip(RoundedCornerShape(17.dp))
            .background(Brush.horizontalGradient(listOf(trackColor, lerp(trackColor, Violet, 0.35f * p))))
            .toggleable(value = checked, enabled = enabled, role = Role.Switch, onValueChange = onCheckedChange),
        contentAlignment = Alignment.TopStart
    ) {
        Box(
            modifier = Modifier
                .offset { IntOffset((pad + travel * progress).roundToInt(), pad.roundToInt()) }
                .size(28.dp)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color.White, Color(0xFFD7E4FF))))
        )
    }
}
