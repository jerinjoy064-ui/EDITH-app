package com.edith.smarthome.ui.dashboard

import androidx.lifecycle.ViewModel
import com.edith.smarthome.model.DashboardUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Stage 1: UI state only. No device transport exists yet, so every link is
 * reported as not connected and relay states stay UNKNOWN (never assumed).
 * Stage 2/3 replace this with a DeviceRepository fed by Wi-Fi and BLE.
 */
class DashboardViewModel : ViewModel() {
    private val _state = MutableStateFlow(DashboardUiState())
    val state: StateFlow<DashboardUiState> = _state.asStateFlow()

    fun onRelayToggle(id: Int) { /* wired to DeviceRepository in Stage 3 */ }

    fun onMasterChanged(on: Boolean) { /* wired to DeviceRepository in Stage 3 */ }
}
