package com.edith.smarthome.ui.dashboard

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.edith.smarthome.model.DashboardUiState
import com.edith.smarthome.model.LinkState
import com.edith.smarthome.model.RelayPower
import com.edith.smarthome.model.RelayUi
import com.edith.smarthome.ui.components.GlassCard
import com.edith.smarthome.ui.components.LiquidSwitch
import com.edith.smarthome.ui.theme.Amber
import com.edith.smarthome.ui.theme.Bg0
import com.edith.smarthome.ui.theme.Bg1
import com.edith.smarthome.ui.theme.Cyan
import com.edith.smarthome.ui.theme.Green
import com.edith.smarthome.ui.theme.Red
import com.edith.smarthome.ui.theme.TextPrimary
import com.edith.smarthome.ui.theme.TextSecondary
import com.edith.smarthome.ui.theme.Violet
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun DashboardScreen(viewModel: DashboardViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val now by rememberNow()
    val connected = state.esp32 == LinkState.CONNECTED

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg1, Bg0)))) {
        GlowBlobs()
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 150.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Header(state, now)
            StatusRow(state)
            MasterCard(state, connected, viewModel::onMasterChanged)
            state.relays.chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    pair.forEach { relay ->
                        RelayCard(
                            relay = relay,
                            enabled = connected && !relay.pending,
                            onToggle = { viewModel.onRelayToggle(relay.id) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
            if (!connected) {
                Text(
                    "Not connected to EDITH. Local control only (Wi-Fi or Bluetooth LE). Relay states are unknown until the device confirms them.",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        VoiceButton(
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 24.dp),
            onClick = { /* voice assistant arrives in Stage 4 */ }
        )
    }
}

@Composable
private fun rememberNow(): State<LocalDateTime> = produceState(LocalDateTime.now()) {
    while (true) {
        value = LocalDateTime.now()
        delay(1000)
    }
}

@Composable
private fun GlowBlobs() {
    Canvas(Modifier.fillMaxSize()) {
        val r = size.width * 0.8f
        val c1 = Offset(size.width * 0.9f, size.height * 0.08f)
        val c2 = Offset(size.width * 0.05f, size.height * 0.75f)
        drawCircle(
            Brush.radialGradient(listOf(Cyan.copy(alpha = 0.22f), Color.Transparent), center = c1, radius = r),
            radius = r, center = c1
        )
        drawCircle(
            Brush.radialGradient(listOf(Violet.copy(alpha = 0.22f), Color.Transparent), center = c2, radius = r),
            radius = r, center = c2
        )
    }
}

@Composable
private fun Header(state: DashboardUiState, now: LocalDateTime) {
    val time = now.format(DateTimeFormatter.ofPattern("HH:mm"))
    val date = now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()))
    val online = state.esp32 == LinkState.CONNECTED
    Row(verticalAlignment = Alignment.CenterVertically) {
        LogoOrb(online)
        Spacer(Modifier.width(14.dp))
        Column {
            Text("EDITH", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
            Text(
                if (online) "Online · ${state.activeTransport ?: "local"}" else "Offline · no device",
                color = if (online) Green else TextSecondary,
                style = MaterialTheme.typography.labelSmall
            )
        }
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text(time, color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.Light)
            Text(date, color = TextSecondary, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun LogoOrb(online: Boolean) {
    val pulse by rememberInfiniteTransition(label = "orb").animateFloat(
        initialValue = 0.35f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "pulse"
    )
    val core = if (online) Cyan else TextSecondary
    Canvas(Modifier.size(48.dp)) {
        drawCircle(Brush.sweepGradient(listOf(Cyan, Violet, Cyan)), style = Stroke(width = 4.dp.toPx()))
        drawCircle(core.copy(alpha = if (online) pulse else 0.5f), radius = size.minDimension * 0.18f)
    }
}

private fun LinkState.color(): Color = when (this) {
    LinkState.CONNECTED -> Green
    LinkState.CONNECTING -> Amber
    LinkState.UNAVAILABLE -> Red
    LinkState.OFF -> TextSecondary
}

private fun LinkState.label(): String = when (this) {
    LinkState.CONNECTED -> "Connected"
    LinkState.CONNECTING -> "Connecting"
    LinkState.UNAVAILABLE -> "Unavailable"
    LinkState.OFF -> "Off"
}

@Composable
private fun StatusRow(state: DashboardUiState) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatusChip("Wi-Fi", Icons.Rounded.Wifi, state.wifi, Modifier.weight(1f))
        StatusChip("Bluetooth", Icons.Rounded.Bluetooth, state.bluetooth, Modifier.weight(1f))
        StatusChip("ESP32", Icons.Rounded.Memory, state.esp32, Modifier.weight(1f))
    }
}

@Composable
private fun StatusChip(name: String, icon: ImageVector, link: LinkState, modifier: Modifier) {
    GlassCard(modifier = modifier) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = name, tint = link.color(), modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Box(Modifier.size(7.dp).clip(CircleShape).background(link.color()))
            }
            Text(name, color = TextPrimary, style = MaterialTheme.typography.labelSmall)
            Text(link.label(), color = link.color(), style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun MasterCard(state: DashboardUiState, enabled: Boolean, onChange: (Boolean) -> Unit) {
    val allOn = state.relays.all { it.power == RelayPower.ON }
    GlassCard(modifier = Modifier.fillMaxWidth(), glow = if (allOn) Cyan.copy(alpha = 0.5f) else null) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.PowerSettingsNew, contentDescription = null, tint = if (allOn) Cyan else TextSecondary)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Master", color = TextPrimary, style = MaterialTheme.typography.titleMedium)
                Text("All relays", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
            }
            LiquidSwitch(checked = allOn, enabled = enabled, onCheckedChange = onChange)
        }
    }
}

@Composable
private fun RelayCard(relay: RelayUi, enabled: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    val on = relay.power == RelayPower.ON
    val status = when {
        relay.pending -> "Waiting for device…"
        relay.power == RelayPower.ON -> "ON"
        relay.power == RelayPower.OFF -> "OFF"
        else -> "Unknown"
    }
    GlassCard(modifier = modifier, glow = if (on) Cyan.copy(alpha = 0.55f) else null) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.size(44.dp).clip(CircleShape)
                    .background(if (on) Cyan.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.08f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Lightbulb, contentDescription = null, tint = if (on) Cyan else TextSecondary)
            }
            Text(relay.name, color = TextPrimary, style = MaterialTheme.typography.titleMedium)
            Text(status, color = if (on) Cyan else TextSecondary, style = MaterialTheme.typography.labelSmall)
            LiquidSwitch(checked = on, enabled = enabled, onCheckedChange = { onToggle() })
        }
    }
}

@Composable
private fun VoiceButton(modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(Cyan, Violet)))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Rounded.Mic, contentDescription = "Voice assistant", tint = Bg0, modifier = Modifier.size(32.dp))
    }
}
