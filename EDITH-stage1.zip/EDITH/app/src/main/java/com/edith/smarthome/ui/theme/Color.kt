package com.edith.smarthome.ui.theme

import androidx.compose.ui.graphics.Color

val Bg0 = Color(0xFF05070D)
val Bg1 = Color(0xFF0B1226)
val Cyan = Color(0xFF4DD2FF)
val Violet = Color(0xFF8B7BFF)
val Green = Color(0xFF3DDC97)
val Amber = Color(0xFFFFC857)
val Red = Color(0xFFFF5C6C)
val TextPrimary = Color(0xFFF2F5FF)
val TextSecondary = Color(0xFF9AA6C4)
