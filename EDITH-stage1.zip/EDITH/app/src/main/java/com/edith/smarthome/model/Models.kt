package com.edith.smarthome.model

enum class RelayPower { UNKNOWN, ON, OFF }

enum class LinkState { OFF, CONNECTING, CONNECTED, UNAVAILABLE }

data class RelayUi(
    val id: Int,
    val name: String,
    val power: RelayPower = RelayPower.UNKNOWN,
    val pending: Boolean = false
)

data class DashboardUiState(
    val wifi: LinkState = LinkState.OFF,
    val bluetooth: LinkState = LinkState.OFF,
    val esp32: LinkState = LinkState.OFF,
    val activeTransport: String? = null,
    val relays: List<RelayUi> = (1..4).map { RelayUi(it, "Relay $it") }
)
