# EDITH Android app
Works with the unmodified EDITH firmware (BLE `edith`, UDP 4210 commands, UDP 4211 audio).

## Build with GitHub Actions (no PC needed)
1. Create a GitHub repo. Upload `edith-android.zip` to the repo root (Add file > Upload files).
2. Add file > Create new file, name it `.github/workflows/build.yml`, paste the workflow, commit.
3. Actions tab > Build EDITH APK > when green, download `EDITH-debug-apk` and install the .apk.

## Firmware limits the app works around
- Over Wi-Fi the firmware only replies "OK". It never sends relay status by UDP, so Wi-Fi state is tracked by the app. Switch presses on the box show up only over BLE.
- BLE status notifications can be cut to the negotiated MTU; the app re-reads the status value to get all four relays.
- No Wi-Fi discovery or mDNS. The app broadcasts STATUS and reads the "OK" sender, or tries 192.168.4.1 (EDITH hotspot).
- Microphone: firmware only reads the MAX9814 level and discards it. Voice recognition runs on the phone.
- Speaker: raw 16 kHz mono PCM over Wi-Fi only (not BLE).
- Hourly event is "HOURLY|hh:mm" (12-hour, no AM/PM). The phone clock decides the greeting. Quiet hours are enforced by the firmware.
- No authentication or encryption on BLE or UDP.
