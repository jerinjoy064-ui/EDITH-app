package com.edith.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale

class Voice(private val ctx: Context, private val link: EdithLink) {
    private val tts = TextToSpeech(ctx) { }

    /** Speaks on the phone and/or on EDITH's speaker (TTS -> 16 kHz mono PCM -> UDP 4211). Malayalam text uses ml-IN. */
    fun speak(text: String, phone: Boolean, edith: Boolean) {
        val ml = text.any { it in '\u0D00'..'\u0D7F' }
        tts.language = Locale.forLanguageTag(if (ml) "ml-IN" else "en-IN")
        if (phone) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "p")
        if (edith) {
            val f = File(ctx.cacheDir, "tts.wav")
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(u: String?) {}
                override fun onError(u: String?) {}
                override fun onDone(u: String?) { if (u == "e") runCatching { link.streamPcm(toPcm16k(f.readBytes())) } }
            })
            tts.synthesizeToFile(text, null, f, "e")
        }
    }

    private fun toPcm16k(w: ByteArray): ByteArray {
        val bb = ByteBuffer.wrap(w).order(ByteOrder.LITTLE_ENDIAN)
        val ch = bb.getShort(22).toInt(); val sr = bb.getInt(24)
        val n = (w.size - 44) / 2 / ch
        val src = ShortArray(n) { bb.getShort(44 + it * 2 * ch) }
        val outN = (n.toLong() * 16000 / sr).toInt()
        val out = ByteBuffer.allocate(outN * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until outN) {
            val p = i.toDouble() * sr / 16000
            val j = p.toInt().coerceAtMost(n - 1); val k = (j + 1).coerceAtMost(n - 1)
            out.putShort((src[j] + (src[k] - src[j]) * (p - j)).toInt().toShort())
        }
        return out.array()
    }

    fun listen(ml: Boolean, onText: (String) -> Unit, onState: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { onState("Speech recognition unavailable"); return }
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { onState("Listening…") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onError(e: Int) { onState("Didn't catch that ($e)"); r.destroy() }
            override fun onResults(b: Bundle) {
                onText(b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()); r.destroy()
            }
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (ml) "ml-IN" else "en-IN")
        )
    }
}

/** Voice text -> existing firmware commands (R1=ON ... ALL=OFF). Runs on the phone; firmware has no voice parsing. */
object Cmd {
    private val on = listOf("on", "start", "ഓൺ", "ഇടൂ", "ഇട്", "ഇടുക", "കത്തിക്ക", "തെളിയിക്ക", "തുറക്ക")
    private val off = listOf("off", "stop", "ഓഫ്", "അണയ്ക്ക", "അണക്ക", "നിർത്ത", "ഇല്ലാതാക്ക")
    private val tog = listOf("toggle", "മാറ്റ")
    private val all = listOf("all", "everything", "എല്ലാം", "എല്ലാ")
    private val nums = listOf(
        listOf("1", "one", "ഒന്ന്", "ഒന്നാം", "ഒന്ന"), listOf("2", "two", "രണ്ട്", "രണ്ടാം"),
        listOf("3", "three", "മൂന്ന്", "മൂന്നാം"), listOf("4", "four", "നാല്", "നാലാം", "നാല")
    )
    private fun has(t: String, w: List<String>, k: List<String>) =
        k.any { if (it[0].code < 128) it in w else t.contains(it) }

    fun parse(text: String, names: List<String>): List<String> {
        val t = text.lowercase(); val w = t.split(Regex("[\\s,.!?]+"))
        val s = when {
            has(t, w, off) -> "OFF"; has(t, w, on) -> "ON"; has(t, w, tog) -> "TOGGLE"; else -> return emptyList()
        }
        if (has(t, w, all)) return listOf("ALL=$s")
        val hit = (0..3).filter { i -> names[i].isNotBlank() && t.contains(names[i].lowercase()) || has(t, w, nums[i]) }
        return hit.map { "R${it + 1}=$s" }
    }
}

/** AI chat. Needs your own Anthropic API key (entered in Settings, stored only on this phone). */
object Claude {
    fun ask(key: String, system: String, msgs: List<Pair<String, String>>): String {
        val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 500).put("system", system)
            .put("messages", JSONArray().apply { msgs.forEach { put(JSONObject().put("role", it.first).put("content", it.second)) } })
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
        c.setRequestProperty("x-api-key", key); c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = c.responseCode in 200..299
        val s = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
        if (!ok) return "AI error ${c.responseCode}: " + runCatching { JSONObject(s).getJSONObject("error").getString("message") }.getOrDefault("")
        val a = JSONObject(s).getJSONArray("content")
        return (0 until a.length()).joinToString("") { a.getJSONObject(it).optString("text") }
    }
}
