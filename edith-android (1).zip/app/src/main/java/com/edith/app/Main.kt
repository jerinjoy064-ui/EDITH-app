package com.edith.app

import android.Manifest
import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions
import androidx.activity.result.contract.ActivityResultContracts.RequestPermission
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

val Mint = Color(0xFF7EF0D4)
val Lilac = Color(0xFFB69CFF)

class VM(app: Application) : AndroidViewModel(app) {
    private val sp = app.getSharedPreferences("edith", 0)
    val link = EdithLink(app)
    private val voice = Voice(app, link)
    val names = MutableStateFlow(List(4) { sp.getString("n$it", "Relay ${it + 1}")!! })
    val ml = MutableStateFlow(sp.getBoolean("ml", false))
    val ip = MutableStateFlow(sp.getString("ip", "")!!)
    val key = MutableStateFlow(sp.getString("key", "")!!)
    val inv = MutableStateFlow(sp.getBoolean("inv", false))
    val greet = MutableStateFlow(true)
    val toPhone = MutableStateFlow(true)
    val toEdith = MutableStateFlow(false)
    val status = MutableStateFlow("")
    val chat = MutableStateFlow(listOf<Pair<String, String>>())

    init {
        link.ip = ip.value
        link.invert = inv.value
        link.onIp = { setIp(it) }
        link.listen()
        link.startWifi()
        viewModelScope.launch { link.hourly.collect { onHourly() } }
    }

    fun setIp(v: String) { ip.value = v; link.ip = v; sp.edit().putString("ip", v).apply() }
    fun setInv(v: Boolean) { inv.value = v; link.invert = v; sp.edit().putBoolean("inv", v).apply() }
    fun setKey(v: String) { key.value = v; sp.edit().putString("key", v).apply() }
    fun setMl(v: Boolean) { ml.value = v; sp.edit().putBoolean("ml", v).apply() }
    fun rename(i: Int, n: String) {
        names.update { l -> l.toMutableList().also { it[i] = n.ifBlank { "Relay ${i + 1}" } } }
        sp.edit().putString("n$i", names.value[i]).apply()
    }
    private fun say(t: String) = voice.speak(t, toPhone.value, toEdith.value)

    private fun onHourly() {
        if (!greet.value) return
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val h12 = if (h % 12 == 0) 12 else h % 12
        val hello = when (h) { in 5..11 -> "Good morning"; in 12..16 -> "Good afternoon"; else -> "Good evening" }
        say(if (ml.value) "നമസ്കാരം സർ. സമയം $h12 മണി." else "$hello Sir. It is $h12 o'clock.")
    }

    fun listen() = voice.listen(ml.value, { t ->
        val c = Cmd.parse(t, names.value)
        if (c.isEmpty()) { status.value = "“$t”"; ask(t) }
        else {
            c.forEach { link.send(it) }
            val reply = if (ml.value) "ശരി സർ" else "Done, Sir."
            status.value = "“$t” → ${c.joinToString()}"
            chat.update { it + ("user" to t) + ("assistant" to reply) }
            say(reply)
        }
    }, { status.value = it })

    fun ask(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            chat.update { it + ("user" to text) }
            if (key.value.isBlank()) { chat.update { it + ("assistant" to "Add your Anthropic API key in Settings to chat.") }; return@launch }
            val state = names.value.mapIndexed { i, n -> "R${i + 1}=$n(${if (link.relays.value[i] != inv.value) "ON" else "OFF"})" }.joinToString()
            val sys = "You are EDITH, a concise home assistant. Reply in the user's language (English or Malayalam), under 60 words, plain text. Relays: $state. " +
                "Only when the user asks to switch something, end your reply with tokens like [[R1=ON]] [[R2=OFF]] [[R3=TOGGLE]] [[ALL=OFF]]."
            val hist = chat.value.takeLast(12).dropWhile { it.first != "user" }
            val r = withContext(Dispatchers.IO) { runCatching { Claude.ask(key.value, sys, hist) }.getOrElse { "Network error: ${it.message}" } }
            Regex("\\[\\[(R[1-4]=(?:ON|OFF|TOGGLE)|ALL=(?:ON|OFF))]]").findAll(r).forEach { link.send(it.groupValues[1]) }
            val clean = r.replace(Regex("\\[\\[.*?]]"), "").trim()
            chat.update { it + ("assistant" to clean) }
            say(clean)
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, hot: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    val s = RoundedCornerShape(24.dp)
    Column(
        modifier.clip(s)
            .background(Brush.linearGradient(listOf(Color.White.copy(.20f), Color.White.copy(.05f))))
            .border(1.dp, Brush.linearGradient(listOf(if (hot) Mint.copy(.9f) else Color.White.copy(.45f), Color.White.copy(.06f))), s)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun GBtn(t: String, mod: Modifier = Modifier, hot: Boolean = false, f: () -> Unit) {
    val s = RoundedCornerShape(16.dp)
    Box(
        mod.clip(s).background(if (hot) Mint.copy(.28f) else Color.White.copy(.12f))
            .border(1.dp, Color.White.copy(.35f), s).clickable { f() }.padding(14.dp),
        Alignment.Center
    ) { Text(t, color = Color.White, fontWeight = FontWeight.Medium) }
}

@Composable
fun App(vm: VM = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF120B2E), Color(0xFF0B2F45), Color(0xFF2A1148))))) {
        Box(Modifier.offset((-90).dp, (-80).dp).size(380.dp).background(Brush.radialGradient(listOf(Color(0xFF7A5CFF).copy(.55f), Color.Transparent)), CircleShape))
        Box(Modifier.align(Alignment.BottomEnd).offset(100.dp, 90.dp).size(400.dp).background(Brush.radialGradient(listOf(Color(0xFF19D3B0).copy(.5f), Color.Transparent)), CircleShape))
        Column(Modifier.fillMaxSize().safeDrawingPadding().padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Control", "Chat", "Settings").forEachIndexed { i, n -> GBtn(n, Modifier.weight(1f), tab == i) { tab = i } }
            }
            Spacer(Modifier.height(14.dp))
            Box(Modifier.weight(1f)) { when (tab) { 0 -> Home(vm); 1 -> ChatTab(vm); else -> SettingsTab(vm) } }
        }
    }
}

@Composable
fun Home(vm: VM) {
    val relays by vm.link.relays.collectAsState(); val names by vm.names.collectAsState()
    val ble by vm.link.ble.collectAsState(); val wifi by vm.link.wifi.collectAsState()
    val ml by vm.ml.collectAsState(); val st by vm.status.collectAsState(); val inv by vm.inv.collectAsState()
    var rename by remember { mutableIntStateOf(-1) }
    var draft by remember { mutableStateOf("") }
    val btPerm = rememberLauncherForActivityResult(RequestMultiplePermissions()) { vm.link.connectBle() }
    val micPerm = rememberLauncherForActivityResult(RequestPermission()) { if (it) vm.listen() }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("EDITH", fontSize = 34.sp, fontWeight = FontWeight.Light, color = Color.White, letterSpacing = 6.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Glass(Modifier.weight(1f).clickable { btPerm.launch(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)) }, ble == "Connected") {
                Text("Bluetooth", color = Color.White, fontWeight = FontWeight.SemiBold); Text(ble, color = Lilac, fontSize = 13.sp)
            }
            Glass(Modifier.weight(1f).clickable { vm.link.find() }, wifi.startsWith("Wi-Fi") || wifi.startsWith("Found")) {
                Text("Wi-Fi", color = Color.White, fontWeight = FontWeight.SemiBold); Text(wifi, color = Lilac, fontSize = 13.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GBtn("All on", Modifier.weight(1f), true) { vm.link.send("ALL=ON") }
            GBtn("All off", Modifier.weight(1f)) { vm.link.send("ALL=OFF") }
        }
        for (row in 0..1) Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            for (c in 0..1) {
                val i = row * 2 + c
                val on = relays[i] != inv
                Glass(Modifier.weight(1f), on) {
                    Text(names[i], color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { draft = names[i]; rename = i })
                    Text(if (on) "On" else "Off", color = if (on) Mint else Color(0xFFB9B2DA))
                    Switch(on, { vm.link.send("R${i + 1}=" + if (it) "ON" else "OFF") })
                }
            }
        }
        Text("Tap a relay name to rename it", color = Color.White.copy(.5f), fontSize = 12.sp)
        Glass(Modifier.fillMaxWidth()) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GBtn("🎙 Speak", Modifier.weight(1f), true) { micPerm.launch(Manifest.permission.RECORD_AUDIO) }
                GBtn(if (ml) "മലയാളം" else "English", Modifier.weight(1f)) { vm.setMl(!ml) }
            }
            if (st.isNotBlank()) Text(st, color = Color.White.copy(.8f), modifier = Modifier.padding(top = 10.dp))
        }
    }
    if (rename >= 0) AlertDialog(
        onDismissRequest = { rename = -1 },
        title = { Text("Rename relay ${rename + 1}") },
        text = { OutlinedTextField(draft, { draft = it }, singleLine = true) },
        confirmButton = { TextButton({ vm.rename(rename, draft); rename = -1 }) { Text("Save") } },
        dismissButton = { TextButton({ rename = -1 }) { Text("Cancel") } }
    )
}

@Composable
fun ChatTab(vm: VM) {
    val msgs by vm.chat.collectAsState()
    var text by remember { mutableStateOf("") }
    val state = rememberLazyListState()
    val micPerm = rememberLauncherForActivityResult(RequestPermission()) { if (it) vm.listen() }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) state.animateScrollToItem(msgs.lastIndex) }
    Column {
        LazyColumn(Modifier.weight(1f), state = state, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(msgs) { (role, t) ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (role == "user") Alignment.CenterEnd else Alignment.CenterStart) {
                    Glass(Modifier.widthIn(max = 300.dp), role == "user") { Text(t, color = Color.White) }
                }
            }
        }
        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Ask EDITH") })
            GBtn("🎙") { micPerm.launch(Manifest.permission.RECORD_AUDIO) }
            GBtn("Send", hot = true) { vm.ask(text); text = "" }
        }
    }
}

@Composable
fun SettingsTab(vm: VM) {
    val ip by vm.ip.collectAsState(); val key by vm.key.collectAsState()
    val inv by vm.inv.collectAsState(); val greet by vm.greet.collectAsState(); val phone by vm.toPhone.collectAsState(); val edith by vm.toEdith.collectAsState()
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Glass(Modifier.fillMaxWidth()) {
            Text("EDITH Wi-Fi address", color = Color.White, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(ip, { vm.setIp(it.trim()) }, singleLine = true, placeholder = { Text("192.168.4.1 on the EDITH hotspot") })
            Spacer(Modifier.height(10.dp))
            Text("Anthropic API key (AI chat)", color = Color.White, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(key, { vm.setKey(it.trim()) }, singleLine = true, visualTransformation = PasswordVisualTransformation())
        }
        Glass(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Invert relays (use if On/Off is reversed)", Modifier.weight(1f), Color.White); Switch(inv, { vm.setInv(it) }) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Speak hourly greeting", Modifier.weight(1f), Color.White); Switch(greet, { vm.greet.value = it }) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Replies on this phone", Modifier.weight(1f), Color.White); Switch(phone, { vm.toPhone.value = it }) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Replies on EDITH speaker (Wi-Fi)", Modifier.weight(1f), Color.White); Switch(edith, { vm.toEdith.value = it }) }
        }
    }
}
