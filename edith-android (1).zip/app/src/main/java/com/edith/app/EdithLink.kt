package com.edith.app

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.ParcelUuid
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.net.*
import java.util.UUID

val SVC: UUID = UUID.fromString("8b9a1000-7d2b-4c6a-9a00-112233445566")
val CMD: UUID = UUID.fromString("8b9a1001-7d2b-4c6a-9a00-112233445566")
val STA: UUID = UUID.fromString("8b9a1002-7d2b-4c6a-9a00-112233445566")
val CCC: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

/** Talks to the already-flashed EDITH firmware: BLE (status + commands) and UDP 4210/4211. No new protocol. */
@SuppressLint("MissingPermission")
class EdithLink(private val ctx: Context) {
    val relays = MutableStateFlow(List(4) { false })
    val ble = MutableStateFlow("Tap to connect")
    val wifi = MutableStateFlow("Tap to find")
    val hourly = MutableSharedFlow<String>(extraBufferCapacity = 4)
    var ip = ""
    var invert = false
    var onIp: ((String) -> Unit)? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var gatt: BluetoothGatt? = null
    private var cmdC: BluetoothGattCharacteristic? = null
    private var staC: BluetoothGattCharacteristic? = null
    val bleUp get() = cmdC != null
    private var lastH = ""; private var lastHT = 0L

    // ---- GATT operation queue (Android allows one GATT op at a time) ----
    private val q = ArrayDeque<() -> Boolean>()
    private var busy = false
    @Synchronized private fun enqueue(op: () -> Boolean) { q.add(op); if (!busy) pump() }
    @Synchronized private fun pump() {
        while (true) {
            val op = q.removeFirstOrNull() ?: run { busy = false; return }
            busy = true
            if (op()) return
        }
    }
    @Synchronized private fun done() { busy = false; pump() }

    fun connectBle() {
        val bt = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (bt == null || !bt.isEnabled) { ble.value = "Turn Bluetooth on"; return }
        if (bleUp) { gatt?.disconnect(); return }
        ble.value = "Scanning…"
        val sc = bt.bluetoothLeScanner
        val cb = object : ScanCallback() {
            override fun onScanResult(t: Int, r: ScanResult) {
                sc.stopScan(this); ble.value = "Connecting…"
                gatt = r.device.connectGatt(ctx, false, gattCb, BluetoothDevice.TRANSPORT_LE)
            }
            override fun onScanFailed(e: Int) { ble.value = "Scan failed ($e)" }
        }
        sc.startScan(
            listOf(ScanFilter.Builder().setServiceUuid(ParcelUuid(SVC)).build()),
            ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), cb
        )
        scope.launch { delay(12000); if (gatt == null) { sc.stopScan(cb); ble.value = "EDITH not found" } }
    }

    private val gattCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, s: Int, n: Int) {
            if (n == BluetoothProfile.STATE_CONNECTED) g.requestMtu(185)
            else { g.close(); gatt = null; cmdC = null; staC = null; q.clear(); busy = false; ble.value = "Disconnected" }
        }
        override fun onMtuChanged(g: BluetoothGatt, m: Int, s: Int) { g.discoverServices() }
        override fun onServicesDiscovered(g: BluetoothGatt, s: Int) {
            val svc = g.getService(SVC) ?: run { ble.value = "EDITH service missing"; return }
            cmdC = svc.getCharacteristic(CMD); staC = svc.getCharacteristic(STA)
            g.setCharacteristicNotification(staC, true)
            ble.value = "Connected"
            enqueue { g.writeDescriptor(staC!!.getDescriptor(CCC), BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) == BluetoothStatusCodes.SUCCESS }
            enqueue { g.writeCharacteristic(cmdC!!, "STATUS".toByteArray(), BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothStatusCodes.SUCCESS }
        }
        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, s: Int) = done()
        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, s: Int) = done()
        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, v: ByteArray, s: Int) { onText(String(v), false); done() }
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, v: ByteArray) = onText(String(v), true)
    }

    private fun onText(t: String, notify: Boolean) {
        when {
            t.startsWith("HOURLY|") -> {
                val now = System.currentTimeMillis()
                if (t != lastH || now - lastHT > 5000) { lastH = t; lastHT = now; hourly.tryEmit(t.removePrefix("HOURLY|")) }
            }
            t.startsWith("STATUS") -> {
                val m = Regex("R([1-4])=(ON|OFF)").findAll(t).toList()
                if (m.isNotEmpty()) relays.update { l -> l.toMutableList().also { x -> m.forEach { x[it.groupValues[1].toInt() - 1] = it.groupValues[2] == "ON" } } }
                // Notifications can be cut to the BLE MTU; re-read the full value when that happens.
                if (m.size < 4 && notify) enqueue { gatt?.readCharacteristic(staC) == true }
            }
        }
    }

    /** BLE when connected (state comes back by notification), otherwise Wi-Fi UDP. */
    fun send(logical: String) {
        val cmd = if (invert) logical.replace("=ON", "=#").replace("=OFF", "=ON").replace("=#", "=OFF") else logical
        if (bleUp) enqueue { gatt!!.writeCharacteristic(cmdC!!, cmd.toByteArray(), BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothStatusCodes.SUCCESS }
        else scope.launch { udp(cmd) }
    }

    private fun applyLocal(c: String) {
        val u = c.uppercase()
        relays.update { l -> l.toMutableList().also { x ->
            when {
                u == "ALL=ON" -> x.fill(true)
                u == "ALL=OFF" -> x.fill(false)
                u.length > 3 && u[0] == 'R' -> {
                    val i = u[1] - '1'
                    if (i in 0..3) x[i] = when { u.endsWith("=ON") -> true; u.endsWith("=OFF") -> false; else -> !x[i] }
                }
            }
        } }
    }

    private fun sock() = DatagramSocket().apply {
        broadcast = true; soTimeout = 700
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.allNetworks.firstOrNull { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true }?.bindSocket(this)
    }

    private fun udp(cmd: String): Boolean {
        if (ip.isBlank()) { wifi.value = "No IP: tap to find"; return false }
        return runCatching {
            sock().use { s ->
                val b = cmd.toByteArray()
                s.send(DatagramPacket(b, b.size, InetAddress.getByName(ip), 4210))
                val r = DatagramPacket(ByteArray(128), 128); s.receive(r)
                val rep = String(r.data, 0, r.length)
                val ok = rep == "OK" || rep.startsWith("STATUS")
                if (ok) {
                    if (rep.startsWith("STATUS")) onText(rep, false) else applyLocal(cmd)
                    wifi.value = "Wi-Fi ready"
                }
                ok
            }
        }.getOrElse { wifi.value = "No reply from $ip"; false }
    }

    /** Discovery without a new protocol: firmware answers "OK" to any UDP command, so broadcast STATUS and read the sender. */
    fun find() = scope.launch {
        wifi.value = "Searching…"
        // Subnet broadcasts of every active interface (covers router Wi-Fi AND phone hotspot), then fallbacks.
        val subnet = runCatching {
            NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }
                .flatMap { it.interfaceAddresses }.mapNotNull { it.broadcast?.hostAddress }
        }.getOrDefault(emptyList())
        for (target in (subnet + listOf("255.255.255.255", "192.168.4.1")).distinct()) {
            val found = runCatching {
                sock().use { s ->
                    val b = "STATUS".toByteArray()
                    s.send(DatagramPacket(b, b.size, InetAddress.getByName(target), 4210))
                    val r = DatagramPacket(ByteArray(128), 128); s.receive(r)
                    val rep = String(r.data, 0, r.length)
                    if (rep == "OK" || rep.startsWith("STATUS")) r.address.hostAddress else null
                }
            }.getOrNull()
            if (found != null) { ip = found; wifi.value = "Found $found"; onIp?.invoke(found); return@launch }
        }
        wifi.value = "Not found. Enter IP in Settings"
    }

    private var wifiJob: Job? = null
    /** Auto-finds EDITH on Wi-Fi and keeps relay state in sync (every 4 s) while Bluetooth is not connected. */
    fun startWifi() {
        if (wifiJob?.isActive == true) return
        wifiJob = scope.launch {
            var misses = 0
            while (isActive) {
                if (ip.isBlank()) { find().join(); delay(3000); continue }
                if (!bleUp) {
                    if (udp("STATUS")) misses = 0
                    else if (++misses >= 3) { misses = 0; find().join() }
                }
                delay(4000)
            }
        }
    }

    /** Firmware broadcasts HOURLY|hh:mm to UDP 4210 on the LAN. */
    fun listen() {
        scope.launch {
            runCatching {
                DatagramSocket(null).use { s ->
                    s.reuseAddress = true; s.bind(InetSocketAddress(4210))
                    val r = DatagramPacket(ByteArray(64), 64)
                    while (isActive) { r.length = 64; s.receive(r); onText(String(r.data, 0, r.length), false) }
                }
            }
        }
    }

    /** Streams 16 kHz / 16-bit / mono PCM to UDP 4211 in real time (firmware plays raw PCM only). */
    fun streamPcm(pcm: ByteArray) = scope.launch {
        if (ip.isBlank()) return@launch
        runCatching {
            sock().use { s ->
                val a = InetAddress.getByName(ip); val t0 = System.nanoTime(); var off = 0
                while (off < pcm.size) {
                    val n = minOf(640, pcm.size - off)
                    s.send(DatagramPacket(pcm, off, n, a, 4211)); off += n
                    val wait = (t0 + (off / 2) * 62_500L - 60_000_000L - System.nanoTime()) / 1_000_000
                    if (wait > 0) Thread.sleep(wait)
                }
            }
        }
    }
}
